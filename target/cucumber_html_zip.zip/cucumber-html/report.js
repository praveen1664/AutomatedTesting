$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/resources/FeatureFiles/Test.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "This is a test feature",
  "description": "I want to use this template for my feature file",
  "id": "this-is-a-test-feature",
  "keyword": "Feature"
});
formatter.before({
  "duration": 25644745,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Title of your scenario first scenario",
  "description": "",
  "id": "this-is-a-test-feature;title-of-your-scenario-first-scenario",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 23,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "open the browser",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "enter your mailid",
  "keyword": "Then "
});
formatter.match({
  "location": "Test.open_the_browser()"
});
formatter.result({
  "duration": 75791921379,
  "status": "passed"
});
formatter.match({
  "location": "Test.enter_your_mailid()"
});
formatter.result({
  "duration": 4671281,
  "error_message": "java.lang.Exception\r\n\tat com.optum.acoe.StepDefinitions.Test.enter_your_mailid(Test.java:52)\r\n\tat ✽.Then enter your mailid(src/test/resources/FeatureFiles/Test.feature:26)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 66526486,
  "status": "passed"
});
});